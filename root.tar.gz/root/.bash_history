history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
nano /etc/hosts
vim /etc/hosts
vim/etc/hosts
vim /etc/hosts
vim /etc/hosts
cat /etc/hosts
hostnamectl
exec bash
ip a
ip r
cat /etc/resolv.conf
ping -c3 8.8.8.8
ping -c2 deb.debian.org
cat /etc/apt/sources.list
cp /etc/apt/sources.list /etc/apt/sources.list.bak
cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian bullseye main contrib non-free
deb http://deb.debian.org/debian bullseye-updates main contrib non-free
deb http://security.debian.org/debian-security bullseye-security main contrib non-free
EOF

apt update
apt upgrade -y
apt full-upgrade -y
cat > /etc/apt/sources.list << 'EOF'
deb http:/deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http:// EOF
EOF

cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
EOF



apt full-upgrade -y
apt --purge autoremove -y
reboot
exit
lsb_release -a
cat /etc/debian_version
apt install openssh-server -y
systemctl status ssh
mkdir -p /root/.ssh
chmod 700 /root/.ssh
ssh-keygen -t rsa -b 4096 -f /root/.ssh/id_rsa -N ""
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
sed -i`~
sed -i 's/^#*PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
systemctl restart ssh
ssh -i /root/.ssh/id_rsa root@localhost
ls -ls /root
apt install apache2 php libapache2-mod-php php-mysql -y
systemctl status apache2
ls -la /root
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz
cd /root
tar -xzf Material_Adicional_TPVMCA.tar.gz
ls -la /root/Material_Adicional_TPVMCA
file /root/Material_Adicional_TPVMCA/index.php
head -20 /root/Material_Adicional_TPVMCA/index.php
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls -la /var/www/html
ls -la /var/www/html/index.html
>mv /var/www/html/index.html /var/www/html/index.html.bkp
mv /var/www/html/index.html /var/www/html/index.html.bkp
ls -la /var/www/html
systemctl restart apache2
curl http://localhost
curl -i http://localhost
tail -30 /var/log/apache2/error.log
echo "<?php echo 'PHP OK'; ?>" > /var/www/html/test.php
curl http://localhost/test.php
which mysql
systemctl status mariadb
apt update
apt install mariadb-server -y
systemctl start mariadb
systemctl enable mariadb
which mysql
systemctl status mariadb
head -30 /root/Material_Adicional_TPVMCA/db.sql
mysql < /root/Material_Adicional_TPVMCA/db.sql
mysql
curl -i http://localhost
ip a
ip addr
shutdown
shutdown -c
shutdown -g now
shutdown -h now
hostname -I
ip route
cat /etc/network/interfaces
cp /etc/network/interfaces /etc/network/interfaces.bkp
apt update
apt install nano -y
nano /etc/network/interfaces
reboot
ip a
ip route
cat /etc/network/interfaces
nano /cat/network/interfaces
nano /cat/network/interfaces
nano /etc/network/interfaces
reboot
ip addr
shutdown -h now
lsblk
fdisk -l
shutdown -h now
lsblk
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
ls -ld /www_dir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
cp /root/Material_Adicional_TPVMCA/index.php /www_dir/
cp /root/Material_Adicional_TPVMCA/logo.png /www_dir/
ls -la /www_dir
df -h
ls -la /www_dir
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.bkp
nano /etc/apache2/sites-available/000-default.conf
chmod 755 /www_dir
chmod 644 /www_dir/index.php
chmod 644 /www_dir/logo.png
systemctl restart apache2
systemctl status apache2
curl http://localhost
grep -R "/www_dir" /etc/apache2
cat /etc/apache2/apache2.conf | tail -50
grep -R "/www_dir" /etc/apache2
nano /etc/apache2/apache2.conf
apache2ctl configtest
nano /etc/apache2/apache2.conf
apache2ctl configtest
systemctl restart apache2
curl -I http://localhost
blkid /dev/sdc1
blkid /dev/sdc2
nano /etc/fstab
mount -a
df -h
cat /proc/partitions > /opt/particion
cat /opt/particion
reboot
df -h
ls -la /www_dir
ls -la /backup_dir
cat /etc/fstab
cat /opt/particion
mkdir -p /opt/scripts
nano /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
shutdown -h now
